// 
// CHAPTER 38 - 42
//1. Write a custom function power ( a, b ), to calculate the value of a raised to b.
function power(a, b) {
  var result = 1;
  for (var count = 0; count < b; count++)
      result *= a
  return result;
}

console.log(power(2, 10));

//2. Any year is entered through the keyboard. Write a function to determine whether the year is a leap year or not. Leap years ..., 2012, 2016, 2020, …
function leapyear(year) {
  return (year % 100 === 0) ? (year % 400 === 0) : (year % 4 === 0);
}
console.log(leapyear(2016));
console.log(leapyear(2000));
console.log(leapyear(1700));
console.log(leapyear(1800));
console.log(leapyear(100));

//3. If the lengths of the sides of a triangle are denoted by a, b, and c, then area of triangle is given by
//area = S(S − a)(S − b)(S − c)
//where, S = ( a + b + c ) / 2
//Calculate area of triangle using 2 functions
function area(a, b, c) {
  var s = (a + b + c) / 2;
  var area = Math.sqrt(s * ((s - a) * (s - b) * (s - c)));
}
console.log(area(2, 4, 6))

//4. Write a function that receives marks received by a student in 3 subjects and returns the average and percentage of these
//marks. there should be 3 functions one is the mainFunction and other are for average and percentage. Call those functions from mainFunction and display result in mainFunction.

var sub1 = prompt("Enter marks of 1st subject: ");
var sub2 = prompt("Enter marks of 2nd subject: ");
var sub3 = prompt("Enter marks of 3rd subject: ");

function main() {
  document.write("average: "+ average());
  document.write("Percentage: "+percentage());
}

function average() {
var avg = sub1+sub2+sub3;
}

function percentage(){
  var per = ((sub1+sub2+sub3)/300)*100;
}

//5. You have learned the function indexOf. Code your own custom function that will perform the same functionality. You can code for single character as of now.
var str = "a quick brown fox jump over a lazy dog";

function main(){
var index = str.substring(0, str.indexOf('b'));
console.log(index);
}

//6. Write a function to delete all vowels from a sentence. Assume that the sentence is not more than 25 characters long.
var str = prompt("Enter a string: ");

function removeVowels(){
  return str.replace(/[aeiou]/gi, '');
  console.log(str);
}
//7. Write a function with switch statement to count the number of occurrences of any two vowels in succession in a line of text. For example, in the sentence
//“Pleases read this application and give me gratuity”
//Such occurrences are ea, ea, ui.
function vowelOccurrences() {
  var str = "Pleases read this application and give me gratuity";
  var count = 0;

  switch (str) {
      case 'ea':
          count++;
      case 'ui':
          count++
      case 'io':
          count++
      default:
          return 0;
  }
  console.log(count);
}

vowelOccurrences();

//8. The distance between two cities (in km.) is input through the keyboard. Write four functions to convert and print this distance in meters, feet, inches and centimeters.
var distance = prompt(parseInt("Enter distance in KM: "));

function main() {
console.log("distance in meters: "+meters());
console.log("distance in feets: "+feets())
console.log("distance in inches: "+inches())
console.log("distance in centimeters: "+centiMeters())
}

function meters(distance) {
  var m = distance * 1000;
  console.log(m);
}

function feets(distance) {
  var m = distance * 3280.84;
  console.log(m);
}

function inches(distance) {
  var m = distance * 39370.08;
  console.log(m);
}

function centiMeter(distance) {
  var m = distance * 1000 * 100;
  console.log(m);
}
//9. Write a program to calculate overtime pay of employees. Overtime is paid at the rate of Rs. 12.00 per hour for every hour worked above 40 hours. Assume that employees do not work for fractional part of an hour.
function overTimepay(){
  var time =prompt("Enter the time employee worked in hr: ");

  if(time>40){
      var overTime = time-40;
  }
  else{
      alert("Enter worke hour above then 40 ");
  }
  var overTimepay = 12*overTime;
  console.log("Over time pay is "+overTime);
}

overTimepay()

//10. A cashier has currency notes of denominations 10, 50 and 100. If the amount to be withdrawn is input through the keyboard in hundreds, find the total number of currency notes of each denomination the cashier will have to give to the withdrawer.
function currencyNote(){
  var amount = prompt("enter amount: ");

  var hundredNotes = amount / 100;
  var fiftyNotes = (amount % 100) / 50;
  var tenNotes =(((amount % 100) % 50) / 10);
  var remainingAmount = (((amount % 100) % 50) % 10);

  document.write("Notes of Hundreds: "+hundredNotes);
  document.write("Notes of Fifties: "+fiftyNotes);
  document.write("Notes of Tens: "+tenNotes);
  document.write("Remaining Amount: "+remainingAmount);
}
currencyNote()
 //chapter 43-48
 //Q1. 
 document.getElementById('b1').onclick = function(){
	swal("Here's a message!");
};

document.getElementById('b2').onclick = function(){
	swal("Here's a message!", "It's pretty, isn't it?")
};

document.getElementById('b3').onclick = function(){
	swal("Good job!", "You clicked the button!", "success");
};

document.getElementById('b4').onclick = function(){
	swal({
		title: "Are you sure?",
		text: "You will not be able to recover this imaginary file!",
		type: "warning",
		showCancelButton: true,
		confirmButtonColor: '#DD6B55',
		confirmButtonText: 'Yes, delete it!',
		closeOnConfirm: false,
		//closeOnCancel: false
	},
	function(){
		swal("Deleted!", "Your imaginary file has been deleted!", "success");
	});
};

document.getElementById('b5').onclick = function(){
	swal({
		title: "Are you sure?",
		text: "You will not be able to recover this imaginary file!",
		type: "warning",
		showCancelButton: true,
		confirmButtonColor: '#DD6B55',
		confirmButtonText: 'Yes, delete it!',
		cancelButtonText: "No, cancel plx!",
		closeOnConfirm: false,
		closeOnCancel: false
	},
	function(isConfirm){
    if (isConfirm){
      swal("Deleted!", "Your imaginary file has been deleted!", "success");
    } else {
      swal("Cancelled", "Your imaginary file is safe :)", "error");
    }
	});
};

document.getElementById('b6').onclick = function(){
	swal({
		title: "Sweet!",
		text: "Here's a custom image.",
		imageUrl: 'https://i.imgur.com/4NZ6uLY.jpg'
	});
};
//Q2:
function myFunction() {
  var dots = document.getElementById("dots");
  var moreText = document.getElementById("more");
  var btnText = document.getElementById("myBtn");

  if (dots.style.display === "none") {
      dots.style.display = "inline";
      btnText.innerHTML = "Read more";
      moreText.style.display = "none";
  } else {
      dots.style.display = "none";
      btnText.innerHTML = "Read less";
      moreText.style.display = "inline";
  }
}
//Q3:
var obj=[{Firstname:"Bob",Lastname:"Mayer",Email:"bob@mayer.com",Number: "123456789"},{Firstname:"Steven",Lastname:"Spil",Email:"steven@spill.com",Number: "987654321"},{Firstname:"Paul",Lastname:"Taucker",Email:"paul@tack.com",Number: "578954321"}];

var form = document.createElement('form');
form.id="details";
document.body.appendChild(form);

var tableDiv  = document.createElement('div');
tableDiv.setAttribute("id", "tabDiv");
form.appendChild(tableDiv);

var table = document.createElement("table");
table.setAttribute("id", "myTable");
tableDiv.appendChild(table);

var btnDelete = document.createElement('input');
btnDelete.type = "button";
btnDelete.value = "Delete";
btnDelete.onclick = deleteRow;
form.appendChild(btnDelete);

var addForm = document.createElement('div');
form.appendChild(addForm);

var row = document.createElement("tr");
var cell = document.createElement("th");
row.appendChild(cell);
cell.innerHTML = "Select";
var cell = document.createElement("th");
row.appendChild(cell);
cell.innerHTML = "Sl.No";
table.appendChild(row);
Object.keys(obj[0]).forEach(function(val) {
  var cell = document.createElement("th");
  row.appendChild(cell); 
  cell.innerHTML = val;
});
var cell = document.createElement("th");
row.appendChild(cell);
cell.innerHTML = "Action";

for (var i = 0; i < obj.length; i++) {
  var btnSave = document.createElement('button');
  btnSave.innerHTML = "Save";
  btnSave.onclick = saveCell;

  var btnEdit = document.createElement('input');
  btnEdit.type = "button";
  btnEdit.value = "Edit";
  btnEdit.onclick = editCell;
  
  var checkbox = document.createElement('input');
  checkbox.type = "checkbox";
  checkbox.id= "checkBox";

  var row = document.createElement("tr");
  table.appendChild(row);
  var cell = document.createElement("td");
  row.appendChild(cell);
  cell.appendChild(checkbox);
  var cell = document.createElement("td");
  row.appendChild(cell);
  cell.innerHTML = i;
  for (key in obj[i]) {
    var cell = document.createElement("td");
    row.appendChild(cell);
    cell.innerHTML = obj[i][key];
  }
  var cell = document.createElement("td");
  row.appendChild(cell);
  cell.appendChild(btnEdit);
  cell.appendChild(btnSave);
}

var firstname = document.createElement('input');
firstname.type = "text";
firstname.placeholder = "Firstname";
firstname.required = true;
addForm.appendChild(firstname);

var lastname = document.createElement('input');
lastname.type = "text";
lastname.placeholder = "Lastname";
lastname.required = true;
addForm.appendChild(lastname);

var email = document.createElement('input');
email.type = "email";
email.placeholder = "Email";
email.required = true;
addForm.appendChild(email);

var phnumber = document.createElement('input');
phnumber.type = "number";
phnumber.placeholder = "Number";
phnumber.required = true;
addForm.appendChild(phnumber);

var addTable = function() { 
 	var btnSave = document.createElement('button');
  btnSave.innerHTML = "Save";
  btnSave.onclick = saveCell;

  var btnEdit = document.createElement('input');
  btnEdit.type = "button";
  btnEdit.value = "Edit";
  btnEdit.onclick = editCell;
  
  var checkbox = document.createElement('input');
  checkbox.type = "checkbox";
  checkbox.id= "checkBox";
  var row = document.createElement("tr");
  if((firstname.value!="")&&(lastname.value!="")&&(email.value!="")&&(phnumber.value!="")){
  
    table.appendChild(row);
    var cell = document.createElement("td");
  	row.appendChild(cell);
  	cell.appendChild(checkbox);
    
    var cell = document.createElement("td");
    row.appendChild(cell);
    cell.innerHTML = i++;
    
    var cell = document.createElement("td");
    row.appendChild(cell);
    cell.innerHTML = firstname.value;
    
    var cell = document.createElement("td");
    row.appendChild(cell);
    cell.innerHTML = lastname.value;
    
    var cell = document.createElement("td");
    row.appendChild(cell);
    cell.innerHTML = email.value;
    
    var cell = document.createElement("td");
    row.appendChild(cell);
    cell.innerHTML = phnumber.value;
    
    var cell = document.createElement("td");
    row.appendChild(cell);
    cell.appendChild(btnEdit);
    cell.appendChild(btnSave);
    
    document.getElementById("details").reset();
	}
  else {
  	alert("Enter Input Values");
  }
};

var btnClick = document.createElement('input');
btnClick.type = "submit";
btnClick.value = "Add Row";
btnClick.onclick = addTable;
form.appendChild(btnClick);

function deleteRow() {
  var tabDel = document.getElementById('myTable');
  var rowCount = tabDel.rows.length;
  for(var i=0; i<rowCount; i++) {
    var row = tabDel.rows[i];
    var chkbox = row.cells[0].childNodes[0];
    if(chkbox.checked) {
      tabDel.deleteRow(i);
      rowCount--;
      i--;
    }
	}
}

function editCell(e) {

  var t = e.target.parentElement.parentElement;
  var trs = t.getElementsByTagName("tr");
	tds = t.getElementsByTagName("td");

	tds[2].appendChild(firstname);  
  
  tds[3].appendChild(lastname);  
  
  tds[4].appendChild(email);  
  
  tds[5].appendChild(phnumber);  
  curr = t;
}

function saveCell() { 
  if(curr != undefined)
  {
    var inputs = curr.getElementsByTagName("td");
    for(var i = 2; i < inputs.length - 1; i++)
    {
      currInput = inputs[i].getElementsByTagName("input");
      currInput[0].parentElement.innerHTML = currInput[0].value;
    }
    curr = undefined;
  }
}
//Q4in html :
//Q5:
var button = document.getElementById("clickme"),
  count = 0;
button.onclick = function() {
  count += 1;
  button.innerHTML = "Clickme: " + count;
  console.innerHTML =clickme;
};

//chp 49-52

var fname
var lname
var email
var pass


function submit(){

    pass=document.getElementById("pass").value
    fname=document.getElementById("fname").value
    lname=document.getElementById("lname").value
    email=document.getElementById("email").value

    document.write("First Name: "+fname+"<br>Last Name: "+lname+"<br>Email: "+email+"<br>Password: "+pass)

}








function unhide(){

    document.getElementById("read").style.display="none"
    document.getElementById("hide").style.display="block"

}









var name
var id
var clas

var table = document.getElementById('table')

document.getElementById("form").style.display="none"

var x



for (var i = 1; i < table.rows.length; i++) {

  x=i
  table.rows[i].cells[3].onclick = function del() {

    table.deleteRow(   this.parentElement.rowIndex)


  }

  table.rows[i].cells[4].onclick = function edit() {

    id=table.rows[x].cells[0].innerHTML
    name=table.rows[x].cells[1].innerHTML
    clas=table.rows[x].cells[2].innerHTML

    table.style.display="none"
    document.getElementById("form").style.display="block"
    document.getElementById("id").value=id
    document.getElementById("name").value=name
    document.getElementById("clas").value=clas


  }
}
chp58-67





    main=document.getElementById("main-content").children
    for(i=0;i<main.length;i++){
          document.write(main[i].innerHTML+"<br>")
    }

    document.write("<br>")

    document.write("<br>")

    document.write("<br>")

   ren=document.getElementsByClassName("render")

   for(i=0;i<ren.length;i++){
    document.write(ren[i].innerHTML+"<br>")
}



document.getElementById("first-name").value="fatima"
document.getElementById("last-name").value="imdad"
document.getElementById("email").value="Fatima I'm dad132@gmail.com"




document.write(document.getElementById("form-content").nodeType + "<br>")
document.write(document.getElementById("lastName").nodeType, document.getElementById("lastName").childNodes)


var lname=document.getElementById("lastName")

lname.appendChild(document.createTextNode("fatima"))


var main = document.getElementById("main-content").children
var len=document.getElementById("main-content").children.length-1
document.write("<br>"+main[0].innerHTML+"<br>")
document.write("<br>"+main[len].innerHTML+"<br>")

var p=document.getElementById("lastName").nextElementSibling.innerHTML
var n=document.getElementById("lastName").previousElementSibling.innerHTML
document.write("<br>"+p+"<br>")
document.write("<br>"+n+"<br>")


var email =document.getElementById("email").parentNode

document.write("<br>"+email+"<br>"+email.nodeType)
chp52-57



img=[]
img[0]=" file:///C:/Users/starpc/Desktop/Saylani%20work/java3assign/image/others/1.jpg"
img[1]=" file:///C:/Users/starpc/Desktop/Saylani%20work/java3assign/image/others/2.jpg"
img[2]=" file:///C:/Users/starpc/Desktop/Saylani%20work/java3assign/image/others/3.jpg"
img[3]=" file:///C:/Users/starpc/Desktop/Saylani%20work/java3assign/image/others/4.jpg"
img[4]=" file:///C:/Users/starpc/Desktop/Saylani%20work/java3assign/image/others/5.jpg"
img[5]=" file:///C:/Users/starpc/Desktop/Saylani%20work/java3assign/image/others/6.jpg"
img[6]=" file:///C:/Users/starpc/Desktop/Saylani%20work/java3assign/image/others/7.jpg"
img[7]=" file:///C:/Users/starpc/Desktop/Saylani%20work/java3assign/image/others/8.jpg"
img[8]=" file:///C:/Users/starpc/Desktop/Saylani%20work/java3assign/image/others/9.jpg"
img[9]=" file:///C:/Users/starpc/Desktop/Saylani%20work/java3assign/image/others/10.jpg"
img[10]=" file:///C:/Users/starpc/Desktop/Saylani%20work/java3assign/image/others/11.jpg"
img[11]=" file:///C:/Users/starpc/Desktop/Saylani%20work/java3assign/image/others/12.jpg"
img[12]=" file:///C:/Users/starpc/Desktop/Saylani%20work/java3assign/image/others/13.jpg"
img[13]=" file:///C:/Users/starpc/Desktop/Saylani%20work/java3assign/image/others/14.jpg"
img[14]=" file:///C:/Users/starpc/Desktop/Saylani%20work/java3assign/image/others/15.jpg"





var modal = document.getElementById('modal');






for(i=0;i<15;i++){

    document.write(" <img src="+img[i]+" onclick="+modal.classList.add('modal-open'),modal.classList.remove('modal-close')+" > </img>" )
}